<?php

class Categorie_receiptvoucher extends ActiveRecord\Model {

}
