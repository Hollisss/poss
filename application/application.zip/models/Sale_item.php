<?php

class Sale_item extends ActiveRecord\Model {

   public static $table_name = 'sale_items';

}
