<?php

class Sale extends ActiveRecord\Model {


}
