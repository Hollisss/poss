<?php

class Categorie_expence extends ActiveRecord\Model {

}
