<?php

class Receiptvoucher extends ActiveRecord\Model {

}
