<?php

class Category extends ActiveRecord\Model {

}
