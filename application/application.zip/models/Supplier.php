<?php

class Supplier extends ActiveRecord\Model {

}
